f = (111,222)
print(f[0])