import sys
from typing import Collection
from PyQt5.QtWidgets import (QAction, QApplication,QFileDialog, QMainWindow, QMessageBox, QTableWidgetItem, QWidget)# pip install PyQt5
from UI.Ui_MainWin import *
from UI.Ui_th import *
from UI.Ui_NewFile import *
import json


